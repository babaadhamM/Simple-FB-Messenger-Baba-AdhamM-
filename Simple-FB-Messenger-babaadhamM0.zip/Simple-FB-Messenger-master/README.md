# Simple-FB-Messenger
An extension of Google Chrome. Simple stand alone facebook messenger on Desktop.
